import app from 'flarum/common/app';

app.initializers.add('justoverclock/user-statistics', () => {
  console.log('[justoverclock/user-statistics] Hello, forum and admin!');
});
