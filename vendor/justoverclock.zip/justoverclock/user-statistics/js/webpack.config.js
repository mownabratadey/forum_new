module.exports = require('flarum-webpack-config')({
  useExtensions: ['clarkwinkelmann/flarum-ext-likes-received'],
});
